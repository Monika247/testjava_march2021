import java.util.Scanner;

public class Teststudent1 {
  
	public static void main(String[] args) {
		//StudentService ss=new StudentService();
		StudentServices.acceptData();
		StudentServices.displayData();
		int choice=0;
		Scanner sc=new Scanner(System.in);
		//System.out.println(s);
		do {
		System.out.println("1. Search by id\n2.search by name\n3.modify marks\n4.display All\n5.Calculate CGPA\n6.Exit");
		System.out.println("choice");
		choice=sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("enter id");
			int id=sc.nextInt();
			Student s=StudentServices.searchById(id);
			if(s!=null) {
			System.out.println(s);
			}
			else {
				System.out.println("not valid id");
			}
			
			break;
		case 2:
			System.out.println("enter name");
			String nm=sc.next();
			s=StudentServices.searchByName(nm);
			if(s!=null) {
				System.out.println(s);
				}
				else {
					System.out.println("not valid id");
				}
			break;
		case 3:System.out.println("1.Math\n2.Science\n3.History");
		     System.out.println("choice");
		     int ch=sc.nextInt();
		     System.out.println("enter id");
		     id=sc.nextInt();
		     System.out.println("enter marks");
		     float m=sc.nextFloat();
		     boolean ans=StudentServices.modifyMarks(id,m,ch);
		     if(ans)
		     {
		    	 System.out.println("modification done");
		     }
		     else
		    	 System.out.println("not valid id");
			break;
	
		case 4:
			StudentServices.displayData();
			break;
		case 5:System.out.println("enter id");
		        id=sc.nextInt();
		        float gpa=StudentServices.calculatecgpa(id);
		        if(gpa==0.0f)
		        	System.out.println("Student is not found");
		        else
		        	System.out.println("CGPA :"+gpa);
		        		
			break;
		case 6:sc.close();break;
		default:
			System.out.println("wrong choice");
		}
		}while(choice !=6);
	
	}

}