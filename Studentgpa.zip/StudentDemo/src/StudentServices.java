import java.util.Scanner;

public class StudentServices {
	private static Student[] sarr;
	static {
		sarr=new Student[2];
		
	}
	
	///member function
	//accept data for all students
	public static void acceptData() {
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<sarr.length;i++) {
			System.out.println("enetr id");
			int id=sc.nextInt();
			System.out.println("enetr name");
			String nm=sc.next();
			System.out.println("enetr Email");
			String em=sc.next();
			System.out.println("enetr math marks");
			float m1=sc.nextFloat();
			System.out.println("enetr science marks");
			float m2=sc.nextFloat();
			System.out.println("enetr history marks");
			float m3=sc.nextFloat();
			 sarr[i]=new Student(id,nm,em,m1,m2,m3);
		}
		
	}
	
	//search student by id
	public static Student searchById(int id) {
		for(int i=0;i<sarr.length;i++) {
			if(sarr[i].getId()==id) {
				return sarr[i];
				
			}
		}
		return null;
	}
	
	//search student by name
	public static Student searchByName(String nm) {
		for(int i=0;i<sarr.length;i++) {
			if(sarr[i].getName().equals(nm)) {
				return sarr[i];
			}
		}
		return null;
	}
	//Modify marks
	public static boolean modifyMarks(int id,float m,int ch)
	{
		Student s=searchById(id);
		if(s!=null)
		{
			switch(ch)
			{
			case 1:s.setMath(m);break;
			case 2:s.setScience(m);break;
			case 3:s.setHistory(m);break;          
			}
			return true;
		}
		return false;
	}
	//calculate cgpa
	public static float calculatecgpa(int id)
	{
		float gpa=0.0f;
		Student s=searchById(id);
		if(s!=null)
		{
			return s.calculateGpa();
		}
		else
			return gpa;
	}
	//display all students 
	public  static void displayData() {
		for(int i=0;i<sarr.length;i++) {
			System.out.println(sarr[i]);
		}
	}

}
