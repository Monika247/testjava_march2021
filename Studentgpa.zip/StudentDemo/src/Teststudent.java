
public class Teststudent {
	public static void main(String[] args) {
		Student s1=new Student();
		Student s=new Student(12,"Kishori","keerthi@gmail.com",88,99,99);
		//s.display();
		System.out.println(s);
		System.out.println(s.getId());
		s.setName("Rajan");
		System.out.println(s);
		s.setMath(99);
		s.setMath(99);
		System.out.println(s);
	}

}
